/* 
 * File:   Main_Daniel.c
 * Author: ferna
 *
 * Created on December 2, 2025, 10:02 PM
 */

// PIC18F4550 - Solo temperatura local (LM35), compatible con AVR (luz)
// L�nea recibida del AVR:
//   kID=101|L=yy.yylux|D=DD/MM/YYYY|H=HH:MM:SS|CHK=xxxP
// L�nea enviada por el PIC al PC:
//   kID=102|T=tt.tt�C|D=DD/MM/YYYY|H=HH:MM:SS|CHK=xxxP

//================ CONFIG BITS =================
#pragma config FOSC = INTOSCIO_EC   // Oscilador interno, RA6 como I/O
#pragma config PWRT = ON            // Power-up Timer Enable
#pragma config BOR  = ON            // Brown-out Reset Enable
#pragma config WDT  = OFF           // Watchdog Timer Disable
#pragma config MCLRE = ON           // MCLR Pin Enable
#pragma config LVP  = OFF           // Low-Voltage Programming Disable
#pragma config CPD  = OFF           // Data EEPROM Code Protection Disable
#pragma config CP0  = OFF           // Code Protection Disable

#define _XTAL_FREQ 8000000UL        // Oscilador interno 8MHz

#include <xc.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>

//================ CONFIG SENSOR LOCAL =================
#define SENSOR_ID_PIC 102       // ID del sensor LM35 del PIC
#define LM35_CHANNEL  0         // Canal AN0 (RA0)

//================ BUFFERS =================
char rx_buffer_328p[200];       // L�nea recibida del ATmega (k...P)
char pic_buffer[200];           // Payload generado por el PIC (sin k/P)
char tx_final[400];             // Mensaje completo hacia el PC

//================ ESTRUCTURA FECHA/HORA =================
typedef struct {
    uint8_t sec;
    uint8_t min;
    uint8_t hour;
    uint8_t date;
    uint8_t month;
    uint8_t year;   // 0?99 -> se imprime como 20yy
} DateTime;

DateTime pic_time;

//================ PROTOTIPOS =================
void System_Init(void);
void UART_Init(void);
void ADC_Init(void);

void UART_Write_Char(char data);
void UART_Write_String(char *str);
char UART_Read_Char(void);
void UART_Read_Line(char* buffer, uint16_t maxlen);

uint16_t ADC_Read(uint8_t channel);
float    LM35_Get_Temperature(void);

uint8_t  Calculate_Checksum(const char* buffer);
void     Parse_DateTime_From_Message(const char* msg, DateTime* dt);
void     Add_Seconds_To_Time(DateTime* dt, uint8_t seconds);

//====================================================================
// MAIN
//====================================================================
void main(void)
{
    System_Init();
    __delay_ms(100);

    UART_Init();
    __delay_ms(100);

    ADC_Init();
    __delay_ms(100);

    UART_Write_String("PIC18F4550 Iniciado - Solo temperatura (LM35)\r\n");
    UART_Write_String("Oscilador: Interno 8MHz\r\n");
    UART_Write_String("Recibe fecha/hora de AVR\r\n\r\n");

    while (1)
    {
        // 1. Recibir l�nea del ATmega:
        //    kID=101|L=yy.yylux|D=DD/MM/YYYY|H=HH:MM:SS|CHK=xxxP\r\n
        UART_Read_Line(rx_buffer_328p, 200);

        // Limpiar \r\n finales -> queda k...P\0
        uint16_t len = strlen(rx_buffer_328p);
        if (len > 0 && rx_buffer_328p[len-1] == '\n') rx_buffer_328p[--len] = '\0';
        if (len > 0 && rx_buffer_328p[len-1] == '\r') rx_buffer_328p[--len] = '\0';

        // 2. Extraer solo fecha/hora del mensaje recibido
        Parse_DateTime_From_Message(rx_buffer_328p, &pic_time);

        // 3. Sumar 2 segundos a la hora
        Add_Seconds_To_Time(&pic_time, 2);

        // 4. Leer temperatura del LM35 local
        float temperature = LM35_Get_Temperature();

        // Convertir temperatura a entero y decimal
        int16_t  temp_int = (int16_t)temperature;
        uint16_t temp_dec = (uint16_t)((temperature - temp_int) * 100);

        // 5. Construir payload del PIC (sin k/P, sin L=)
        sprintf(pic_buffer,
                "ID=%d|T=%d.%02u�C|D=%02d/%02d/20%02d|H=%02d:%02d:%02d",
                SENSOR_ID_PIC,
                temp_int, temp_dec,
                pic_time.date, pic_time.month, pic_time.year,
                pic_time.hour, pic_time.min, pic_time.sec);

        // Calcular checksum del payload del PIC
        uint8_t checksum_pic = Calculate_Checksum(pic_buffer);
        sprintf(pic_buffer + strlen(pic_buffer), "|CHK=%u", checksum_pic);

        // 6. Construir mensaje final para el PC:
        //    - Primera l�nea: tal como vino del 328P (ya tiene k...P)
        //    - Segunda l�nea: k + payload PIC + P
        sprintf(tx_final, "%s\r\nk%sP\r\n", rx_buffer_328p, pic_buffer);

        // 7. Transmitir mensaje completo
        UART_Write_String(tx_final);

        __delay_ms(100);
    }
}

//====================================================================
// INICIALIZACION SISTEMA
//====================================================================
void System_Init(void)
{
    // Oscilador interno 8MHz
    OSCCON = 0x72;                // IRCF=111 (8MHz), SCS=10 (osc. interno)
    while (!OSCCONbits.IOFS);     // Esperar estabilidad

    // Puertos
    TRISA = 0xFF;                 // RA como entradas (ADC)
    TRISB = 0x00;                 // RB como salidas
    TRISC = 0x80;                 // RC7/RX entrada, RC6/TX salida

    ADCON1 = 0x0E;                // AN0 anal�gico, resto digital
}

//====================================================================
// UART 9600 bps
//====================================================================
void UART_Init(void)
{
    // SPBRG = (Fosc / (16 * Baud)) - 1, con BRGH = 1
    // SPBRG = (8e6 / (16 * 9600)) - 1 ? 51

    TXSTA   = 0x24;               // TXEN=1, BRGH=1
    RCSTA   = 0x90;               // SPEN=1, CREN=1
    BAUDCON = 0x00;               // BRG16=0

    SPBRG = 51;                   // 9600 baudios @ 8MHz

    TRISCbits.TRISC7 = 1;         // RX entrada
    TRISCbits.TRISC6 = 0;         // TX salida
}

void UART_Write_Char(char data)
{
    while (!PIR1bits.TXIF);       // Esperar buffer vac�o
    TXREG = data;
}

void UART_Write_String(char *str)
{
    while (*str)
    {
        UART_Write_Char(*str++);
    }
}

char UART_Read_Char(void)
{
    while (!PIR1bits.RCIF);       // Esperar dato recibido

    // Manejo de overrun
    if (RCSTAbits.OERR) {
        RCSTAbits.CREN = 0;
        RCSTAbits.CREN = 1;
    }

    return RCREG;
}

void UART_Read_Line(char* buffer, uint16_t maxlen)
{
    uint16_t i = 0;
    char c;

    while (i < maxlen - 1)
    {
        c = UART_Read_Char();
        buffer[i++] = c;
        if (c == '\n') break;
    }
    buffer[i] = '\0';
}

//====================================================================
// ADC
//====================================================================
void ADC_Init(void)
{
    ADCON0 = 0x01;                // ADC ON, canal AN0
    ADCON1 = 0x0E;                // AN0 anal�gico, Vref+ = VDD, Vref- = VSS
    ADCON2 = 0xA9;                // Right justified, 12 TAD, Fosc/8

    __delay_ms(1);                // Tiempo de adquisici�n
}

uint16_t ADC_Read(uint8_t channel)
{
    // Seleccionar canal
    ADCON0 = (ADCON0 & 0xC3) | ((channel << 2) & 0x3C);
    ADCON0bits.ADON = 1;

    __delay_us(20);               // Tiempo de adquisici�n

    ADCON0bits.GO = 1;            // Iniciar conversi�n
    while (ADCON0bits.GO);        // Esperar fin

    return ((uint16_t)ADRESH << 8) | ADRESL;
}

//====================================================================
// LM35
//====================================================================
float LM35_Get_Temperature(void)
{
    uint32_t adc_sum = 0;
    uint8_t  samples = 10;

    for (uint8_t i = 0; i < samples; i++) {
        adc_sum += ADC_Read(LM35_CHANNEL);
        __delay_ms(10);
    }

    uint16_t adc_avg = adc_sum / samples;

    // LM35: 10 mV/�C, Vref = 5V, ADC 10 bits
    float temperature = (float)adc_avg * 500.0f / 1024.0f;

    return temperature;
}

//====================================================================
// PARSEO SOLO FECHA/HORA DEL MENSAJE AVR
//====================================================================
static uint8_t two_digits_to_uint8(const char *p)
{
    return (uint8_t)((p[0] - '0') * 10 + (p[1] - '0'));
}

void Parse_DateTime_From_Message(const char* msg, DateTime* dt)
{
    // msg: kID=101|L=yy.yylux|D=DD/MM/YYYY|H=HH:MM:SS|CHK=xxP

    char *date_ptr = strstr(msg, "|D=");
    char *hour_ptr = strstr(msg, "|H=");

    // |D=DD/MM/YYYY
    if (date_ptr != NULL) {
        date_ptr += 3;  // saltar "|D="

        dt->date  = two_digits_to_uint8(date_ptr);      // DD
        dt->month = two_digits_to_uint8(date_ptr + 3);  // MM
        dt->year  = two_digits_to_uint8(date_ptr + 8);  // YY (de YYYY)
    }

    // |H=HH:MM:SS
    if (hour_ptr != NULL) {
        hour_ptr += 3;  // saltar "|H="

        dt->hour = two_digits_to_uint8(hour_ptr);       // HH
        dt->min  = two_digits_to_uint8(hour_ptr + 3);   // MM
        dt->sec  = two_digits_to_uint8(hour_ptr + 6);   // SS
    }
}

//====================================================================
// SUMAR SEGUNDOS
//====================================================================
void Add_Seconds_To_Time(DateTime* dt, uint8_t seconds)
{
    dt->sec += seconds;

    if (dt->sec >= 60) {
        dt->sec -= 60;
        dt->min++;

        if (dt->min >= 60) {
            dt->min -= 60;
            dt->hour++;

            if (dt->hour >= 24) {
                dt->hour -= 24;
                dt->date++;

                // L�gica simplificada de d�as/mes
                if (dt->date > 31) {
                    dt->date = 1;
                    dt->month++;

                    if (dt->month > 12) {
                        dt->month = 1;
                        dt->year++;
                    }
                }
            }
        }
    }
}

//====================================================================
// CHECKSUM
//====================================================================
uint8_t Calculate_Checksum(const char* buffer)
{
    uint8_t sum = 0;

    for (uint16_t i = 0; buffer[i] != '\0'; i++) {
        if (buffer[i] != '\r' && buffer[i] != '\n') {
            sum += (uint8_t)buffer[i];
        }
    }

    return sum;
}
