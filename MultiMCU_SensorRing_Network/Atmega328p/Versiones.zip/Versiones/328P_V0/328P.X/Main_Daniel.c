/* 
 * File:   Main_Daniel.c
 * Author: ferna
 *
 * Created on December 2, 2025, 10:03 PM
 */

// V1 version Bastante Parecida A La Estructura Del Proyecto

#define F_CPU 8000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>

//----------------- CONFIGURACI�N B�SICA -----------------
#define BAUD       9600
#define UBRR_VALUE 51              // (8MHz/(16*9600))-1 = 51

#define ADC_CHANNEL_LIGHT 1        // Fotoresistencia en PC1 (ADC1)
#define LED_PIN           PD7

#define SENSOR_ID_AVR     101      // ID del sensor de luz

// I2C / TWI DS1307
#define DS1307_ADDR 0xD0
#define DS1307_READ 0xD1

// Registros DS1307
#define DS1307_SEC   0x00
#define DS1307_MIN   0x01
#define DS1307_HOUR  0x02
#define DS1307_DAY   0x03
#define DS1307_DATE  0x04
#define DS1307_MONTH 0x05
#define DS1307_YEAR  0x06

#define I2C_TIMEOUT 1000

//----------------- ESTRUCTURAS -----------------
typedef struct {
    uint8_t sec;
    uint8_t min;
    uint8_t hour;
    uint8_t day;
    uint8_t date;
    uint8_t month;
    uint8_t year;
} DateTime;

DateTime current_time;

char send_buffer[200];
uint8_t rtc_error = 0;

//----------------- PROTOTIPOS -----------------
void System_Init(void);
void UART_Init(void);
void I2C_Init(void);
void ADC_Init(void);

void UART_Write_Char(char data);
void UART_Write_String(char *str);

uint8_t  I2C_Start(void);
void     I2C_Stop(void);
uint8_t  I2C_Write(uint8_t data);
uint8_t  I2C_Read(uint8_t ack);

uint8_t  BCD_to_Dec(uint8_t bcd);
uint8_t  RTC_Read(uint8_t reg);
void     RTC_Get_DateTime(DateTime *dt);

uint16_t ADC_Read(uint8_t channel);
float    Get_Light_Level(void);

uint8_t  Calculate_Checksum(const char *data);

//==================================================
// MAIN
//==================================================
int main(void) {
    System_Init();
    _delay_ms(100);

    UART_Init();
    _delay_ms(100);

    ADC_Init();
    _delay_ms(100);

    I2C_Init();
    _delay_ms(100);

    PORTD &= ~(1 << LED_PIN);

    UART_Write_String("ATMEGA328P - Sensor de luz\r\n");
    UART_Write_String("Sensor ID: 101, compatible con PIC\r\n");
    UART_Write_String("Formato: kID|L|D|H|CHKP\r\n\r\n");

    RTC_Get_DateTime(&current_time);
    if (rtc_error) {
        UART_Write_String("ADVERTENCIA: DS1307 no responde\r\n\r\n");
    }

    uint8_t ultimo_segundo = 0;

    while (1) {
        // Leer RTC o simular tiempo si hay error
        if (!rtc_error) {
            RTC_Get_DateTime(&current_time);
        } else {
            current_time.date  = 2;
            current_time.month = 12;
            current_time.year  = 25;
            current_time.hour  = 19;
            current_time.min   = 12;
            current_time.sec++;
            if (current_time.sec >= 60) current_time.sec = 0;
        }

        // Enviar una vez por segundo
        if (current_time.sec != ultimo_segundo) {
            ultimo_segundo = current_time.sec;
            PORTD ^= (1 << LED_PIN);  // Toggle LED

            // Leer sensor de luz (0?100 % aprox.)
            float light_level = Get_Light_Level();

            // Separar parte entera y decimal
            int16_t  luz_int = (int16_t)light_level;
            uint16_t luz_dec = (uint16_t)((light_level - luz_int) * 100);

            // Construir payload sin k/P ni CHK
            char data_only[150];
            sprintf(data_only,
                    "ID=%d|L=%d.%02ulux|D=%02u/%02u/20%02u|H=%02u:%02u:%02u",
                    SENSOR_ID_AVR,
                    luz_int, luz_dec,
                    current_time.date,
                    current_time.month,
                    current_time.year,
                    current_time.hour,
                    current_time.min,
                    current_time.sec);

            // Calcular checksum
            uint8_t chk = Calculate_Checksum(data_only);

            // Trama completa: k ... |CHK=xxP\r\n
            sprintf(send_buffer, "k%s|CHK=%uP\r\n", data_only, chk);
            UART_Write_String(send_buffer);
        }

        _delay_ms(200);
    }

    return 0;
}

//==================================================
// CHECKSUM
//==================================================
uint8_t Calculate_Checksum(const char *data) {
    uint8_t sum = 0;
    uint16_t len = strlen(data);

    for (uint16_t i = 0; i < len; i++) {
        if (data[i] != '\r' && data[i] != '\n') {
            sum += (uint8_t)data[i];
        }
    }
    return sum;
}

//==================================================
// SENSOR DE LUZ
//==================================================
float Get_Light_Level(void) {
    uint32_t adc_sum = 0;
    uint8_t  samples = 10;

    for (uint8_t i = 0; i < samples; i++) {
        adc_sum += ADC_Read(ADC_CHANNEL_LIGHT);
        _delay_ms(10);
    }

    uint16_t adc_avg = adc_sum / samples;

    // Conversi�n aproximada a porcentaje (0?100 %)
    float light_percent = ((float)adc_avg * 100.0f) / 1023.0f;

    return light_percent;
}

//==================================================
// INICIALIZACI�N
//==================================================
void System_Init(void) {
    // LED
    DDRD |= (1 << LED_PIN);
    PORTD |= (1 << LED_PIN);

    // Fotoresistencia: PC1 entrada anal�gica
    DDRC &= ~(1 << PC1);
    PORTC &= ~(1 << PC1);

    // UART: PD0 RX, PD1 TX
    DDRD &= ~(1 << PD0);  // RX entrada
    DDRD |=  (1 << PD1);  // TX salida
}

void UART_Init(void) {
    UBRR0H = (uint8_t)(UBRR_VALUE >> 8);
    UBRR0L = (uint8_t)UBRR_VALUE;

    UCSR0B = (1 << RXEN0) | (1 << TXEN0);        // Habilitar RX/TX
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);      // 8N1
}

void I2C_Init(void) {
    TWSR = 0x00;
    TWBR = 32;                   // ~100 kHz @ 8 MHz
    TWCR = (1 << TWEN);
}

void ADC_Init(void) {
    ADMUX  = (1 << REFS0);                          // AVCC como Vref
    ADCSRA = (1 << ADEN) | (1 << ADPS2) |
             (1 << ADPS1) | (1 << ADPS0);           // Prescaler 128

    _delay_ms(10);
    ADCSRA |= (1 << ADSC);
    while (ADCSRA & (1 << ADSC));
}

//==================================================
// UART helpers
//==================================================
void UART_Write_Char(char data) {
    while (!(UCSR0A & (1 << UDRE0)));
    UDR0 = data;
}

void UART_Write_String(char *str) {
    while (*str) {
        UART_Write_Char(*str++);
    }
}

//==================================================
// ADC
//==================================================
uint16_t ADC_Read(uint8_t channel) {
    ADMUX = (ADMUX & 0xF0) | (channel & 0x0F);
    _delay_us(50);

    ADCSRA |= (1 << ADSC);
    while (ADCSRA & (1 << ADSC));

    uint16_t result = ADCL;
    result |= (ADCH << 8);
    return result;
}

//==================================================
// I2C con timeout + RTC DS1307
//==================================================
uint8_t I2C_Start(void) {
    uint16_t timeout = I2C_TIMEOUT;

    TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);

    while (!(TWCR & (1 << TWINT)) && timeout--) {
        _delay_us(1);
    }

    if (timeout == 0) {
        rtc_error = 1;
        return 0;
    }
    return 1;
}

void I2C_Stop(void) {
    TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN);
    _delay_us(10);
}

uint8_t I2C_Write(uint8_t data) {
    uint16_t timeout = I2C_TIMEOUT;

    TWDR = data;
    TWCR = (1 << TWINT) | (1 << TWEN);

    while (!(TWCR & (1 << TWINT)) && timeout--) {
        _delay_us(1);
    }

    if (timeout == 0) {
        rtc_error = 1;
        return 0;
    }
    return 1;
}

uint8_t I2C_Read(uint8_t ack) {
    uint16_t timeout = I2C_TIMEOUT;

    if (ack) {
        TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWEA);
    } else {
        TWCR = (1 << TWINT) | (1 << TWEN);
    }

    while (!(TWCR & (1 << TWINT)) && timeout--) {
        _delay_us(1);
    }

    if (timeout == 0) {
        rtc_error = 1;
        return 0;
    }
    return TWDR;
}

uint8_t BCD_to_Dec(uint8_t bcd) {
    return ((bcd >> 4) * 10) + (bcd & 0x0F);
}

uint8_t RTC_Read(uint8_t reg) {
    uint8_t data = 0;

    if (!I2C_Start()) return 0;
    if (!I2C_Write(DS1307_ADDR)) { I2C_Stop(); return 0; }
    if (!I2C_Write(reg))         { I2C_Stop(); return 0; }

    if (!I2C_Start()) return 0;
    if (!I2C_Write(DS1307_READ)) { I2C_Stop(); return 0; }
    data = I2C_Read(0);
    I2C_Stop();

    return data;
}

void RTC_Get_DateTime(DateTime *dt) {
    rtc_error = 0;  // reset antes de intentar

    dt->sec = BCD_to_Dec(RTC_Read(DS1307_SEC) & 0x7F);
    if (rtc_error) return;

    dt->min = BCD_to_Dec(RTC_Read(DS1307_MIN) & 0x7F);
    if (rtc_error) return;

    dt->hour = BCD_to_Dec(RTC_Read(DS1307_HOUR) & 0x3F);
    if (rtc_error) return;

    dt->day = BCD_to_Dec(RTC_Read(DS1307_DAY) & 0x07);
    if (rtc_error) return;

    dt->date = BCD_to_Dec(RTC_Read(DS1307_DATE) & 0x3F);
    if (rtc_error) return;

    dt->month = BCD_to_Dec(RTC_Read(DS1307_MONTH) & 0x1F);
    if (rtc_error) return;

    dt->year = BCD_to_Dec(RTC_Read(DS1307_YEAR));
}
