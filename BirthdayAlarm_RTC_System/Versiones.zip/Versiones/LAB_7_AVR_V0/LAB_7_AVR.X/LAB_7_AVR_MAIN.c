/* 
 * File:   LAB_7_AVR_MAIN.c
 * Author: ferna
 *
 * Created on November 19, 2025, 8:55 AM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * Sistema de Alarma de Cumplea�os con RTC DS1307
 * Microcontrolador: ATmega328P (Arduino Uno/Nano)
 * Compilador: avr-gcc
 * Frecuencia: 16MHz
 * Comunicaci�n: I2C (RTC DS1307) y UART (Terminal Serial)
 * 
 * Caracter�sticas:
 * - Almacena fecha de nacimiento
 * - Calcula edad autom�ticamente
 * - Alarma en fecha de cumplea�os con melod�a
 * - M�ltiples modos de operaci�n
 * 
 * PINES:
 * - PC4 (A4) - SDA (I2C)
 * - PC5 (A5) - SCL (I2C)
 * - PD0 (RX) - UART RX
 * - PD1 (TX) - UART TX
 * - PD2 - Buzzer
 */

#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <avr/eeprom.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

// Direcci�n del DS1307
#define DS1307_ADDR 0xD0
#define DS1307_READ 0xD1

// Registros del DS1307
#define DS1307_SEC   0x00
#define DS1307_MIN   0x01
#define DS1307_HOUR  0x02
#define DS1307_DAY   0x03
#define DS1307_DATE  0x04
#define DS1307_MONTH 0x05
#define DS1307_YEAR  0x06

// Direcciones EEPROM para guardar fecha de nacimiento
#define EEPROM_BIRTH_DAY    0x00
#define EEPROM_BIRTH_MONTH  0x01
#define EEPROM_BIRTH_YEAR   0x02
#define EEPROM_ALARM_ENABLE 0x03

// Modos de operaci�n
typedef enum {
    MODE_NORMAL = 0,      // Modo normal: monitorea alarma
    MODE_CONFIG_TIME,     // Configurar fecha/hora actual
    MODE_CONFIG_BIRTH,    // Configurar fecha de nacimiento
    MODE_VIEW_INFO,       // Ver informaci�n
    MODE_TEST             // Modo de prueba
} OperationMode;

// Patr�n r�tmico de cumplea�os
typedef enum {
    CORTO = 200,
    LARGO = 400,
    PAUSA = 100,
    SILENCIO = 300
} Duracion;

const uint16_t melodia_cumpleanos[] = {
    CORTO, PAUSA, CORTO, PAUSA, LARGO, PAUSA, LARGO, PAUSA, LARGO, PAUSA, LARGO, SILENCIO,
    CORTO, PAUSA, CORTO, PAUSA, LARGO, PAUSA, LARGO, PAUSA, LARGO, PAUSA, LARGO, SILENCIO,
    0
};

// Estructura para fecha y hora
typedef struct {
    uint8_t sec;
    uint8_t min;
    uint8_t hour;
    uint8_t day;
    uint8_t date;
    uint8_t month;
    uint8_t year;
} DateTime;

// Estructura para fecha de nacimiento
typedef struct {
    uint8_t day;
    uint8_t month;
    uint8_t year;  // A�o completo desde 2000 (ej: 5 = 2005)
} BirthDate;

DateTime current_time;
BirthDate birth_date;
uint8_t alarm_triggered = 0;
uint8_t alarm_enabled = 1;
OperationMode current_mode = MODE_NORMAL;

char uart_buffer[80];

// Prototipos
void System_Init(void);
void I2C_Init(void);
void UART_Init(void);
void Show_Main_Menu(void);
void I2C_Start(void);
void I2C_Stop(void);
void I2C_Write(uint8_t data);
uint8_t I2C_Read(uint8_t ack);
uint8_t BCD_to_Dec(uint8_t bcd);
uint8_t Dec_to_BCD(uint8_t dec);
void RTC_Write(uint8_t reg, uint8_t data);
uint8_t RTC_Read(uint8_t reg);
void RTC_Get_DateTime(DateTime *dt);
void RTC_Set_DateTime(DateTime *dt);
void UART_Write(char data);
void UART_Write_String(char *str);
char UART_Read_NoWait(void);
uint8_t UART_Data_Ready(void);
void Display_DateTime(DateTime *dt);
void Check_Alarm(void);
void Process_UART_Command(void);
uint8_t Read_Number_UART(void);
void Play_Birthday_Melody(void);
void Buzzer_Beep(uint16_t duration);
void Load_Birth_Date(void);
void Save_Birth_Date(void);
uint8_t Calculate_Age(void);
void Display_Birth_Info(void);
void Config_Birth_Date(void);
void Config_Current_Time(void);

int main(void) {
    System_Init();
    _delay_ms(500);
    
    I2C_Init();
    _delay_ms(100);
    
    UART_Init();
    _delay_ms(200);
    
    // Cargar fecha de nacimiento de EEPROM
    Load_Birth_Date();
    
    // Buzzer apagado inicialmente
    PORTD &= ~(1 << PD2);
    
    
    Show_Main_Menu();
    
    while(1) {
        // Leer fecha y hora del RTC
        RTC_Get_DateTime(&current_time);
        
        // Verificar alarma solo en modo normal
        if(current_mode == MODE_NORMAL && alarm_enabled) {
            Check_Alarm();
        }
        
        // Procesar comandos UART
        if(UART_Data_Ready()) {
            Process_UART_Command();
        }
        
        _delay_ms(100);
    }
    
    return 0;
}

void System_Init(void) {
    DDRD |= (1 << PD2);
    PORTD &= ~(1 << PD2);
    DDRD &= ~(1 << PD0);
    DDRD |= (1 << PD1);
}

void Show_Main_Menu(void) {
    UART_Write_String("\r\n=== MENU PRINCIPAL ===\r\n");
    UART_Write_String("Modos de Operacion:\r\n");
    UART_Write_String("  1. Modo Normal (Monitoreo de alarma)\r\n");
    UART_Write_String("  2. Configurar Fecha/Hora Actual\r\n");
    UART_Write_String("  3. Configurar Fecha de Nacimiento\r\n");
    UART_Write_String("  4. Ver Informacion\r\n");
    UART_Write_String("  5. Modo Prueba (Probar melodia)\r\n");
    UART_Write_String("  E. Habilitar/Deshabilitar Alarma\r\n");
    UART_Write_String("  R. Reiniciar Alarma\r\n\r\n");
    UART_Write_String("Selecciona una opcion: ");
}

void I2C_Init(void) {
    TWSR = 0x00;
    TWBR = 72;
    TWCR = (1 << TWEN);
}

void UART_Init(void) {
    uint16_t ubrr = 103;
    UBRR0H = (uint8_t)(ubrr >> 8);
    UBRR0L = (uint8_t)ubrr;
    UCSR0B = (1 << RXEN0) | (1 << TXEN0);
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void I2C_Start(void) {
    TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
    while(!(TWCR & (1 << TWINT)));
}

void I2C_Stop(void) {
    TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN);
    _delay_us(10);
}

void I2C_Write(uint8_t data) {
    TWDR = data;
    TWCR = (1 << TWINT) | (1 << TWEN);
    while(!(TWCR & (1 << TWINT)));
}

uint8_t I2C_Read(uint8_t ack) {
    if(ack) {
        TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWEA);
    } else {
        TWCR = (1 << TWINT) | (1 << TWEN);
    }
    while(!(TWCR & (1 << TWINT)));
    return TWDR;
}

uint8_t BCD_to_Dec(uint8_t bcd) {
    return ((bcd >> 4) * 10) + (bcd & 0x0F);
}

uint8_t Dec_to_BCD(uint8_t dec) {
    return ((dec / 10) << 4) | (dec % 10);
}

void RTC_Write(uint8_t reg, uint8_t data) {
    I2C_Start();
    I2C_Write(DS1307_ADDR);
    I2C_Write(reg);
    I2C_Write(data);
    I2C_Stop();
}

uint8_t RTC_Read(uint8_t reg) {
    uint8_t data;
    I2C_Start();
    I2C_Write(DS1307_ADDR);
    I2C_Write(reg);
    I2C_Start();
    I2C_Write(DS1307_READ);
    data = I2C_Read(0);
    I2C_Stop();
    return data;
}

void RTC_Get_DateTime(DateTime *dt) {
    dt->sec = BCD_to_Dec(RTC_Read(DS1307_SEC) & 0x7F);
    dt->min = BCD_to_Dec(RTC_Read(DS1307_MIN) & 0x7F);
    dt->hour = BCD_to_Dec(RTC_Read(DS1307_HOUR) & 0x3F);
    dt->day = BCD_to_Dec(RTC_Read(DS1307_DAY) & 0x07);
    dt->date = BCD_to_Dec(RTC_Read(DS1307_DATE) & 0x3F);
    dt->month = BCD_to_Dec(RTC_Read(DS1307_MONTH) & 0x1F);
    dt->year = BCD_to_Dec(RTC_Read(DS1307_YEAR));
}

void RTC_Set_DateTime(DateTime *dt) {
    RTC_Write(DS1307_SEC, Dec_to_BCD(dt->sec));
    RTC_Write(DS1307_MIN, Dec_to_BCD(dt->min));
    RTC_Write(DS1307_HOUR, Dec_to_BCD(dt->hour));
    RTC_Write(DS1307_DAY, Dec_to_BCD(dt->day));
    RTC_Write(DS1307_DATE, Dec_to_BCD(dt->date));
    RTC_Write(DS1307_MONTH, Dec_to_BCD(dt->month));
    RTC_Write(DS1307_YEAR, Dec_to_BCD(dt->year));
}

void UART_Write(char data) {
    while(!(UCSR0A & (1 << UDRE0)));
    UDR0 = data;
}

void UART_Write_String(char *str) {
    while(*str) {
        UART_Write(*str++);
    }
}

char UART_Read_NoWait(void) {
    if(UCSR0A & (1 << RXC0)) {
        return UDR0;
    }
    return 0;
}

uint8_t UART_Data_Ready(void) {
    return (UCSR0A & (1 << RXC0));
}

void Display_DateTime(DateTime *dt) {
    sprintf(uart_buffer, "Fecha: %02d/%02d/20%02d  Hora: %02d:%02d:%02d\r\n",
            dt->date, dt->month, dt->year, dt->hour, dt->min, dt->sec);
    UART_Write_String(uart_buffer);
}

void Load_Birth_Date(void) {
    birth_date.day = eeprom_read_byte((uint8_t*)EEPROM_BIRTH_DAY);
    birth_date.month = eeprom_read_byte((uint8_t*)EEPROM_BIRTH_MONTH);
    birth_date.year = eeprom_read_byte((uint8_t*)EEPROM_BIRTH_YEAR);
    alarm_enabled = eeprom_read_byte((uint8_t*)EEPROM_ALARM_ENABLE);
    
    // Si no hay datos v�lidos, usar valores por defecto
    if(birth_date.day == 0xFF || birth_date.day == 0 || birth_date.day > 31) {
        birth_date.day = 27;
        birth_date.month = 11;
        birth_date.year = 5;  // 2005
        alarm_enabled = 1;
        Save_Birth_Date();
    }
}

void Save_Birth_Date(void) {
    eeprom_write_byte((uint8_t*)EEPROM_BIRTH_DAY, birth_date.day);
    eeprom_write_byte((uint8_t*)EEPROM_BIRTH_MONTH, birth_date.month);
    eeprom_write_byte((uint8_t*)EEPROM_BIRTH_YEAR, birth_date.year);
    eeprom_write_byte((uint8_t*)EEPROM_ALARM_ENABLE, alarm_enabled);
}

uint8_t Calculate_Age(void) {
    uint8_t age = current_time.year - birth_date.year;
    
    // Ajustar si a�n no ha cumplido a�os este a�o
    if(current_time.month < birth_date.month) {
        age--;
    } else if(current_time.month == birth_date.month && current_time.date < birth_date.day) {
        age--;
    }
    
    return age;
}

void Display_Birth_Info(void) {
    uint8_t age = Calculate_Age();
    
    UART_Write_String("\r\n=== INFORMACION ALMACENADA ===\r\n\r\n");
    
    UART_Write_String("Fecha/Hora Actual:\r\n");
    Display_DateTime(&current_time);
    
    sprintf(uart_buffer, "\r\nFecha de Nacimiento: %02d/%02d/20%02d\r\n", 
            birth_date.day, birth_date.month, birth_date.year);
    UART_Write_String(uart_buffer);
    
    sprintf(uart_buffer, "Edad Actual: %d anos\r\n", age);
    UART_Write_String(uart_buffer);
    
    sprintf(uart_buffer, "Proximo Cumpleanos: %02d/%02d/20%02d\r\n", 
            birth_date.day, birth_date.month, current_time.year);
    UART_Write_String(uart_buffer);
    
    UART_Write_String("\r\nEstado de Alarma: ");
    if(alarm_enabled) {
        UART_Write_String("HABILITADA\r\n");
    } else {
        UART_Write_String("DESHABILITADA\r\n");
    }
    
    if(alarm_triggered) {
        UART_Write_String("Alarma ya sono hoy!\r\n");
    }
    
    UART_Write_String("\r\n");
}

void Config_Birth_Date(void) {
    current_mode = MODE_CONFIG_BIRTH;
    DateTime temp_birth;
    
    UART_Write_String("\r\n=== CONFIGURAR FECHA DE NACIMIENTO ===\r\n\r\n");
    
    UART_Write_String("Dia de nacimiento (01-31): ");
    birth_date.day = Read_Number_UART();
    
    UART_Write_String("\r\nMes de nacimiento (01-12): ");
    birth_date.month = Read_Number_UART();
    
    UART_Write_String("\r\nAnio de nacimiento (00-99): ");
    birth_date.year = Read_Number_UART();
    
    Save_Birth_Date();
    
    UART_Write_String("\r\n*** Fecha de nacimiento guardada! ***\r\n");
    sprintf(uart_buffer, "Nacimiento: %02d/%02d/20%02d\r\n\r\n", 
            birth_date.day, birth_date.month, birth_date.year);
    UART_Write_String(uart_buffer);
    
    _delay_ms(2000);
    current_mode = MODE_NORMAL;
    Show_Main_Menu();
}

void Config_Current_Time(void) {
    current_mode = MODE_CONFIG_TIME;
    DateTime temp_dt;
    
    UART_Write_String("\r\n=== CONFIGURAR FECHA/HORA ACTUAL ===\r\n\r\n");
    
    UART_Write_String("Dia (01-31): ");
    temp_dt.date = Read_Number_UART();
    
    UART_Write_String("\r\nMes (01-12): ");
    temp_dt.month = Read_Number_UART();
    
    UART_Write_String("\r\nAnio (00-99): ");
    temp_dt.year = Read_Number_UART();
    
    UART_Write_String("\r\nHora (00-23): ");
    temp_dt.hour = Read_Number_UART();
    
    UART_Write_String("\r\nMinuto (00-59): ");
    temp_dt.min = Read_Number_UART();
    
    UART_Write_String("\r\nSegundo (00-59): ");
    temp_dt.sec = Read_Number_UART();
    
    temp_dt.day = 1;
    
    RTC_Set_DateTime(&temp_dt);
    UART_Write_String("\r\n*** Fecha/hora configurada! ***\r\n");
    Display_DateTime(&temp_dt);
    
    _delay_ms(2000);
    current_mode = MODE_NORMAL;
    Show_Main_Menu();
}

void Buzzer_Beep(uint16_t duration) {
    uint16_t cycles = duration * 2;
    for(uint16_t i = 0; i < cycles; i++) {
        PORTD |= (1 << PD2);
        _delay_us(500);
        PORTD &= ~(1 << PD2);
        _delay_us(500);
    }
}

void Play_Birthday_Melody(void) {
    uint16_t index = 0;
    
    while(melodia_cumpleanos[index] != 0) {
        uint16_t duration = melodia_cumpleanos[index];
        
        if(duration == PAUSA) {
            for(uint8_t i = 0; i < 10; i++) {
                _delay_ms(10);
            }
        } else if(duration == SILENCIO) {
            for(uint8_t i = 0; i < 30; i++) {
                _delay_ms(10);
            }
        } else if(duration == CORTO) {
            Buzzer_Beep(200);
        } else if(duration == LARGO) {
            Buzzer_Beep(400);
        }
        
        index++;
    }
    
    PORTD &= ~(1 << PD2);
}

void Check_Alarm(void) {
    if(!alarm_triggered) {
        // Comparar d�a y mes de cumplea�os
        if(current_time.date == birth_date.day &&
           current_time.month == birth_date.month) {
            
            alarm_triggered = 1;
            uint8_t age = Calculate_Age();
            
            UART_Write_String("\r\n");
            UART_Write_String("*\r\n");
            UART_Write_String("***                                         ***\r\n");
            UART_Write_String("***     FELIZ CUMPLEANOS!                   ***\r\n");
            sprintf(uart_buffer, "***     CUMPLES %d A�OS!                     ***\r\n", age);
            UART_Write_String(uart_buffer);
            UART_Write_String("***                                         ***\r\n");
            UART_Write_String("*\r\n\r\n");
            
            Play_Birthday_Melody();
            
            UART_Write_String("\r\nMelodia finalizada.\r\n");
            UART_Write_String("Usa opcion 'R' para reiniciar alarma.\r\n\r\n");
        }
    }
}

uint8_t Read_Number_UART(void) {
    char buffer[10];
    uint8_t i = 0;
    
    while(1) {
        if(UART_Data_Ready()) {
            char c = UART_Read_NoWait();
            
            if(c == '\r' || c == '\n') {
                if(i > 0) {
                    UART_Write_String("\r\n");
                    buffer[i] = '\0';
                    
                    uint8_t num = 0;
                    for(uint8_t j = 0; j < i; j++) {
                        num = num * 10 + (buffer[j] - '0');
                    }
                    return num;
                }
            }
            else if((c == 8 || c == 127) && i > 0) {
                i--;
                UART_Write_String("\b \b");
            }
            else if(c >= '0' && c <= '9' && i < 9) {
                buffer[i++] = c;
                UART_Write(c);
            }
        }
        _delay_ms(10);
    }
}

void Process_UART_Command(void) {
    static char command_buffer[10];
    static uint8_t buffer_index = 0;
    
    char c = UART_Read_NoWait();
    
    if(c == 0) return;
    
    UART_Write(c);
    
    if(c == '\r' || c == '\n') {
        UART_Write_String("\r\n");
        
        if(buffer_index > 0) {
            char cmd = command_buffer[0];
            
            switch(cmd) {
                case '1':
                    current_mode = MODE_NORMAL;
                    UART_Write_String("*** Modo Normal Activado ***\r\n\r\n");
                    Show_Main_Menu();
                    break;
                    
                case '2':
                    Config_Current_Time();
                    break;
                    
                case '3':
                    Config_Birth_Date();
                    break;
                    
                case '4':
                    current_mode = MODE_VIEW_INFO;
                    Display_Birth_Info();
                    Show_Main_Menu();
                    break;
                    
                case '5':
                    current_mode = MODE_TEST;
                    UART_Write_String("\r\n=== MODO PRUEBA ===\r\n");
                    UART_Write_String("Reproduciendo melodia...\r\n");
                    Play_Birthday_Melody();
                    UART_Write_String("Prueba finalizada.\r\n\r\n");
                    current_mode = MODE_NORMAL;
                    Show_Main_Menu();
                    break;
                    
                case 'E':
                case 'e':
                    alarm_enabled = !alarm_enabled;
                    Save_Birth_Date();
                    UART_Write_String("Alarma ");
                    if(alarm_enabled) {
                        UART_Write_String("HABILITADA\r\n\r\n");
                    } else {
                        UART_Write_String("DESHABILITADA\r\n\r\n");
                    }
                    Show_Main_Menu();
                    break;
                    
                case 'R':
                case 'r':
                    alarm_triggered = 0;
                    PORTD &= ~(1 << PD2);
                    UART_Write_String("*** Alarma reiniciada ***\r\n\r\n");
                    Show_Main_Menu();
                    break;
                    
                default:
                    UART_Write_String("Opcion no valida\r\n\r\n");
                    Show_Main_Menu();
                    break;
            }
            
            buffer_index = 0;
        }
    }
    else if(c == 8 || c == 127) {
        if(buffer_index > 0) {
            buffer_index--;
            UART_Write_String(" \b");
        }
    }
    else if(buffer_index < 9) {
        command_buffer[buffer_index++] = c;
        command_buffer[buffer_index] = '\0';
    }
}